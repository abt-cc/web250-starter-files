<?php
require_once('private/initialize.php'); 

var_dump(redirect_to('/public/bird.php'));
