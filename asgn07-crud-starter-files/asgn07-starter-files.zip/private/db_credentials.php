<?php

/**
 * This file has login credentials for your localhost (on your home computer)
 * 
 * Fill in the credentials for your production (Where you host your files onine)
 * 
 * Comment out the Development code before uploading files to your Webhost
 */

// Development - Local
define("DB_SERVER", "localhost");
define("DB_USER", "web250user");
define("DB_PASS", "8N=YwFDn4]");
define("DB_NAME", "wnc_birds");


// Production - SiteGround
// define("DB_SERVER", "localhost");
// define("DB_USER", "");
// define("DB_PASS", "");
// define("DB_NAME", "");
